package com.codefellowship.codefellowship;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodefellowshipApplicationTests {

	@Test
	void contextLoads() {
	}

}
